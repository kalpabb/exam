char seven[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};

 int i;
 int j;
 int k;

void main() {

 TRISC = 0x00;
 PORTC = 0x00;
 TRISB = 0x00;
 PORTB = 0x00;

 for(i=0;i<10;i++){
              PORTB= seven[i];
              delay_ms(100);

 }
 
     for(j=1;j<10;j++){
              PORTC= seven[j];
              for(k=0;k<10;k++){
              PORTB= seven[k];
              delay_ms(100);

 }
   }
}